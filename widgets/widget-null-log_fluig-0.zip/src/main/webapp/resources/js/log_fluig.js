var fluigToolsObj = SuperWidget.extend({

	init: function() {
    },

	bindings: {
		local: {
		}
	}
});